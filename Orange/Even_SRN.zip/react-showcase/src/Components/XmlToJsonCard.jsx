import React, { useState } from 'react';
import styles from '../Card.module.css';

function XmlToJsonCard() {
  const [jsonOutput, setJsonOutput] = useState('Click the button to convert XML to JSON.');

  const handleConvert = () => {
    const xmlString = `
      <student>
          <name>John Doe</name>
          <course>Web Technologies</course>
          <university>PESU</university>
      </student>
    `;
    const parser = new DOMParser();
    const xmlDoc = parser.parseFromString(xmlString, 'application/xml');

    const studentObj = {
      name: xmlDoc.querySelector('name').textContent,
      course: xmlDoc.querySelector('course').textContent,
      university: xmlDoc.querySelector('university').textContent,
    };

    setJsonOutput(JSON.stringify(studentObj, null, 2));
  };

  return (
    <div className={styles.card}>
      <h2>🔄 XML to JSON Conversion</h2>
      <p>Demonstrate parsing XML and converting it to JSON format.</p>
      <button onClick={handleConvert}>Convert</button>
      <div className={styles.output}>
        <pre>{jsonOutput}</pre>
      </div>
    </div>
  );
}

export default XmlToJsonCard;