import React, { useState } from "react";
import axios from "axios"; 
import styles from "../Card.module.css";

function AsyncFetchCard() {
  const [data, setData] = useState("Click the button to fetch data.");

  const handleFetchData = async () => {
    setData("Fetching data...");
    try {
      
      const response = await axios.get("https://jsonplaceholder.typicode.com/posts/1");
      
      
      setData(`Title: ${response.data.title}, Body: ${response.data.body}`);
    } catch (error) {
      setData(`Error: ${error.message}`);
    }
  };

  return (
    <div className={styles.card}>
      <h2>⚙️ Axios Async Fetch</h2>
      <p>Using Axios with async/await to fetch data from an API.</p>
      <button onClick={handleFetchData}>Fetch Data</button>
      <div className={styles.output}>{data}</div>
    </div>
  );
}

export default AsyncFetchCard;
