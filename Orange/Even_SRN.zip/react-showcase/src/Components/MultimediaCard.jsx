import React from 'react';
import styles from '../Card.module.css';
// 1. Import your local video file
import localVideo from '../assets/type_shi.mp4'; 

function MultimediaCard() {
  return (
    <div className={styles.card}>
      <h2>🎥 HTML5 Multimedia</h2>
      <p>Embed and control video and audio elements.</p>
      
      {/* 2. Use the imported video in the src attribute */}
      <video controls width="100%">
        <source src={localVideo} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      
      <audio controls>
        <source src="https://www.w3schools.com/html/horse.ogg" type="audio/ogg" />
        Your browser does not support the audio element.
      </audio>
    </div>
  );
}

export default MultimediaCard;