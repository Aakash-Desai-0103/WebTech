import React, { useState } from 'react';
import styles from '../Card.module.css';

function GeolocationCard() {
  const [location, setLocation] = useState('Click the button to see your location.');

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      setLocation('Fetching location...');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation(`Latitude: ${latitude.toFixed(4)}, Longitude: ${longitude.toFixed(4)}`);
        },
        (error) => {
          setLocation(`Error: ${error.message}`);
        }
      );
    } else {
      setLocation('Geolocation is not supported by this browser.');
    }
  };

  return (
    <div className={styles.card}>
      <h2>📍 Geolocation API</h2>
      <p>Get and display the user's current location.</p>
      <button onClick={handleGetLocation}>Get My Location</button>
      <div className={styles.output}>{location}</div>
    </div>
  );
}

export default GeolocationCard;