import React from 'react';
import './App.css'; // We'll create this next
import MultimediaCard from './Components/MultimediaCard';
import GeolocationCard from './Components/GeolocationCard';
import AsyncFetchCard from './Components/AsyncFetchCard';
import XmlToJsonCard from './Components/XmlToJsonCard';

function App() {
  return (
    <>
      <header className="header">
        <h1>Web Technology Showcase</h1>
      </header>
      <main className="showcase-container">
        <MultimediaCard />
        <GeolocationCard />
        <AsyncFetchCard />
        <XmlToJsonCard />
      </main>
    </>
  );
}

export default App;