import "./index.css";
import TravelMedia from "./components/TravelMedia.jsx";
import CurrentLocation from "./components/CurrentLocation.jsx";
import UserProfile from "./components/UserProfile.jsx";
import XmlToJson from "./components/XmlToJson.jsx";

function App() {
  return (
    <div className="dashboard">
      <h2 className="dashboard-heading">Smart Travel Companion Dashboard</h2>
      <div className="dashboard-grid">
        <div className="dashboard-item"><TravelMedia /></div>
        <div className="dashboard-item"><CurrentLocation /></div>
        <div className="dashboard-item"><UserProfile /></div>
        <div className="dashboard-item"><XmlToJson /></div>
      </div>
    </div>
  );
}

export default App;
