import React from "react";
function TravelMedia() {
  return (
    <div className="card">
      <h3>Travel Media</h3>
      <video controls width="100%">
        <source src="/assets/welcome.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </div>
  );
}
export default TravelMedia;
