import React, { useState } from "react";

function getLocation() {
  return new Promise((resolve, reject) => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    } else {
      reject(new Error("Geolocation not supported."));
    }
  });
}

function CurrentLocation() {
  const [location, setLocation] = useState(null);

  const handleGetLocation = async () => {
    try {
      const pos = await getLocation();
      setLocation({
        latitude: pos.coords.latitude,
        longitude: pos.coords.longitude
      });
    } catch (err) {
      setLocation({ error: err.message });
    }
  };

  return (
    <div className="card">
      <h3>Locate Me</h3>
      <button className="btn" onClick={handleGetLocation}>Get Location</button>
      {location && location.latitude && (
        <div>
          <div>Latitude: {location.latitude}</div>
          <div>Longitude: {location.longitude}</div>
        </div>
      )}
      {location && location.error && (
        <div style={{ color: "red" }}>{location.error}</div>
      )}
    </div>
  );
}
export default CurrentLocation;
