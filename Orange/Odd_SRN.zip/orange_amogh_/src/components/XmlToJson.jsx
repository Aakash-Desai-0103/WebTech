import React, { useState } from "react";
const bookingXml = `
<travel>
  <name>Alex</name>
  <destinations>
    <destination>Paris</destination>
    <destination>London</destination>
  </destinations>
</travel>`;
async function parseXml(xml) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const nameMatch = xml.match(/<name>(.*?)<\/name>/);
      const name = nameMatch ? nameMatch[1] : "";
      const destinations = (xml.match(/<destination>(.*?)<\/destination>/g) || [])
        .map(tag => tag.replace(/<\/?destination>/g, ''));
      resolve({ name, destinations });
    }, 100);
  });
}
function XmlToJson() {
  const [json, setJson] = useState(null);

  const handleConvert = async () => {
    const result = await parseXml(bookingXml);
    setJson(result);
  };

  return (
    <div className="card">
      <h3>XML to JSON Conversion</h3>
      <textarea readOnly style={{ width: "100%", height: 60 }} value={bookingXml.trim()} />
      <button className="btn" style={{marginTop:8}} onClick={handleConvert}>
        Convert to JSON
      </button>
      {json && (
        <pre style={{ marginTop: 8 }}>{JSON.stringify(json, null, 2)}</pre>
      )}
    </div>
  );
}
export default XmlToJson;
