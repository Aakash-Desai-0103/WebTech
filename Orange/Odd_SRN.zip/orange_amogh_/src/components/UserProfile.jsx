import React, { useState } from "react";
import axios from "axios";
function UserProfile() {
  const [user, setUser] = useState(null);

  const fetchUser = async () => {
    try {
      const { data } = await axios.get("https://jsonplaceholder.typicode.com/users/1");
      setUser(data);
    } catch {
      setUser({ error: "Fetch failed." });
    }
  };

  return (
    <div className="card">
      <h3>User Data (Axios Fetch)</h3>
      <button className="btn" onClick={fetchUser}>Fetch User</button>
      {user && !user.error && (
        <div style={{ marginTop: 8 }}>
          <div>Name: {user.name}</div>
          <div>Email: {user.email}</div>
          <div>Phone: {user.phone}</div>
        </div>
      )}
      {user && user.error && (
        <div style={{ color: "red" }}>{user.error}</div>
      )}
    </div>
  );
}
export default UserProfile;
